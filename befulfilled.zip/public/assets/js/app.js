//@prepros-append vendor/jquery.min.js
//@prepros-append vendor/popper.min.js
//@prepros-append vendor/bootstrap.min.js
//@prepros-append component/custom.js