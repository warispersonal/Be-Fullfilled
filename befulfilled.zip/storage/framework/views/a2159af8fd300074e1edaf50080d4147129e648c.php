<div class="SideMenu-Left">
    <div class="aside-menu">
        <ul>

            <li class="active"><a href="<?php echo e(route('admin')); ?>"><i class="icon-manage-users"></i> Manage Users</a></li>
            <li><a href="<?php echo e(route('flip_the_switch')); ?>"><i class="icon-flip-the-switch"></i> Flip the Switch</a></li>
            <li><a href="<?php echo e(route('content_library')); ?>"><i class="icon-content-library"></i> Content Library</a></li>
            <li><a href="<?php echo e(route('podcast')); ?>"><i class="icon-podcasts"></i> Podcasts</a></li>

            <div class="spriter-line"></div>

            <li><a href="<?php echo e(route('manage_store')); ?>"><i class="icon-manage-store"></i> Manage Store</a></li>
            <li><a href="<?php echo e(route('all_orders')); ?>"><i class="icon-orders"></i> Orders</a></li>
            <li><a href="<?php echo e(route('finance_dashboard')); ?>"><i class="icon-finance-dashboard"></i> Finance Dashboard</a></li>
            <li><a href="<?php echo e(route('faq')); ?>"><i class="icon-faq"></i> FAQ</a></li>
            <li><a href="<?php echo e(route('feedback')); ?>"><i class="icon-feedback"></i> Feedback</a></li>
            <li><a href="<?php echo e(route('send_push_notification')); ?>"><i class="icon-push-notifications"></i> Push Notifications</a></li>
            <li><a href="<?php echo e(route('terms_and_condition')); ?>"><i class="icon-terms"></i> Terms & Conditions</a></li>

            <div class="spriter-line"></div>

            <div class="LogoutHead">
                <h6>Powered by the App guys<br/> Be Fulfilled © 2021 *</h6>
                <a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                   document.getElementById('logout-form').submit();"><i class="icon-logout"></i> Log Out</a>
            </div>

        </ul>
    </div>
</div>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH D:\laragon\www\befulfilled\resources\views/components/navigation/side-bar.blade.php ENDPATH**/ ?>