<script src="<?php echo e(asset('assets/js/app-dist.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>

</body>
</html>
<?php /**PATH D:\laragon\www\befulfilled\resources\views/partials/admin/_footer.blade.php ENDPATH**/ ?>