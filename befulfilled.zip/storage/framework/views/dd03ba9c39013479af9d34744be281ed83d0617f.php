<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title','..:: BE FULFILLED ::..'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontello/css/fontello.css')); ?>"/>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>"/>
    <link rel="icon" type="image/ico" href="<?php echo e(asset('images/favicon.ico')); ?>"/>
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>
<?php /**PATH D:\laragon\www\befulfilled\resources\views/partials/admin/_head.blade.php ENDPATH**/ ?>