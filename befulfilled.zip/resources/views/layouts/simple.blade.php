@include('partials.admin._head')

<div class="main-container">
    @yield('content')
</div>

@include('partials.admin._footer')

