<script src="{{asset('assets/js/app-dist.js')}}"></script>
@yield('js')

</body>
</html>
